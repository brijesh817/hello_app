#!/bin/sh
gradlew clean build generateRelease
